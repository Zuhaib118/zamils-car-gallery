import type { Car, BodyType, Transmission, FuelType } from '@/types';

export interface FilterState {
  query: string;
  brand: string;
  bodyType: BodyType | '';
  fuelType: FuelType | '';
  transmission: Transmission | '';
  origin: '' | 'Pakistani' | 'Japanese';
  collection: string; // collection id, or '' for none
  maxPrice: number; // in PKR
  sort: 'default' | 'price-asc' | 'price-desc' | 'year-desc' | 'year-asc';
}

export const MAX_PRICE_BOUND = 26000000;

export const defaultFilters: FilterState = {
  query: '',
  brand: '',
  bodyType: '',
  fuelType: '',
  transmission: '',
  origin: '',
  collection: '',
  maxPrice: MAX_PRICE_BOUND,
  sort: 'default',
};

export function applyFilters(cars: Car[], f: FilterState): Car[] {
  const q = f.query.trim().toLowerCase();
  let out = cars.filter((c) => {
    if (q && !`${c.name} ${c.brand} ${c.modelYear}`.toLowerCase().includes(q)) return false;
    if (f.brand && c.brand !== f.brand) return false;
    if (f.bodyType && c.bodyType !== f.bodyType) return false;
    if (f.fuelType && c.fuelType !== f.fuelType) return false;
    if (f.transmission && c.transmission !== f.transmission) return false;
    if (f.origin && c.origin !== f.origin) return false;
    if (f.collection && !c.category.split(',').includes(f.collection)) return false;
    if (c.pricePKR > f.maxPrice) return false;
    return true;
  });

  switch (f.sort) {
    case 'price-asc':
      out = [...out].sort((a, b) => a.pricePKR - b.pricePKR);
      break;
    case 'price-desc':
      out = [...out].sort((a, b) => b.pricePKR - a.pricePKR);
      break;
    case 'year-desc':
      out = [...out].sort((a, b) => b.modelYear - a.modelYear);
      break;
    case 'year-asc':
      out = [...out].sort((a, b) => a.modelYear - b.modelYear);
      break;
  }
  return out;
}

export function isDefaultFilters(f: FilterState): boolean {
  return (
    !f.query &&
    !f.brand &&
    !f.bodyType &&
    !f.fuelType &&
    !f.transmission &&
    !f.origin &&
    !f.collection &&
    f.maxPrice === MAX_PRICE_BOUND &&
    f.sort === 'default'
  );
}
