export function formatPKR(value: number): string {
  if (value >= 10000000) {
    return `Rs ${(value / 10000000).toFixed(2)} Cr`;
  }
  if (value >= 100000) {
    return `Rs ${(value / 100000).toFixed(2)} Lac`;
  }
  return `Rs ${value.toLocaleString('en-PK')}`;
}

export function formatPKRFull(value: number): string {
  return `PKR ${value.toLocaleString('en-PK')}`;
}

export function formatMileage(km: number): string {
  return `${km.toLocaleString('en-PK')} km`;
}
