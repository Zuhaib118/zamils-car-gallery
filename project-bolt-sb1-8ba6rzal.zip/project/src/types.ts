export type BodyType =
  | 'Pickup'
  | 'SUV'
  | 'Sedan'
  | 'Hatchback'
  | 'Crossover'
  | 'Coupe';

export type Transmission = 'Automatic' | 'Manual' | 'CVT';

export type FuelType = 'Petrol' | 'Diesel' | 'Hybrid' | 'Electric';

export type Origin = 'Pakistani' | 'Japanese';

export interface CarSpec {
  label: string;
  value: string;
}

export interface Car {
  id: number;
  name: string;
  brand: string;
  modelYear: number;
  bodyType: BodyType;
  transmission: Transmission;
  fuelType: FuelType;
  mileage: number; // km
  pricePKR: number;
  origin: Origin;
  category: string; // collection ids this car belongs to
  image: string;
  gallery: string[];
  condition: string;
  engine: string;
  description: string;
  specs: CarSpec[];
}

export interface Collection {
  id: string;
  title: string;
  description: string;
  cover: string;
  carIds: number[];
  tag: string;
}
