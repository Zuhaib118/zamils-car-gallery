/**
 * Central site configuration — easy to edit.
 * Replace the placeholder WhatsApp number and contact details with your own.
 */
export const SITE = {
  brand: "Zamil's Car Gallery",
  tagline: 'Drive Your Dream. Discover Your Next Journey.',
  // WhatsApp number in international format, digits only (no +, spaces, or dashes).
  // Example: 92 300 1234567 -> '923001234567'
  whatsappNumber: '923000000000',
  phoneDisplay: '+92 300 000 0000',
  email: 'contact@zamilscargallery.example',
  address: 'Showroom Road, City, Pakistan',
  social: {
    facebook: 'https://facebook.com',
    instagram: 'https://instagram.com',
    youtube: 'https://youtube.com',
    tiktok: 'https://tiktok.com',
  },
};

export function whatsappLink(message: string) {
  return `https://wa.me/${SITE.whatsappNumber}?text=${encodeURIComponent(message)}`;
}
