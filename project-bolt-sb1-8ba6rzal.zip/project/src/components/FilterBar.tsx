import { Search, SlidersHorizontal, X, ArrowUpDown } from 'lucide-react';
import type { FilterState } from '@/lib/filters';
import { MAX_PRICE_BOUND } from '@/lib/filters';
import type { BodyType, Transmission, FuelType } from '@/types';
import { formatPKR } from '@/lib/format';

interface FilterBarProps {
  filters: FilterState;
  onChange: (next: FilterState) => void;
  onClear: () => void;
  brands: string[];
  isDirty: boolean;
}

const BODY_TYPES: BodyType[] = ['Pickup', 'SUV', 'Sedan', 'Hatchback', 'Crossover'];
const FUELS: FuelType[] = ['Petrol', 'Diesel', 'Hybrid'];
const TRANS: Transmission[] = ['Automatic', 'Manual', 'CVT'];
const SORTS: { value: FilterState['sort']; label: string }[] = [
  { value: 'default', label: 'Default' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'year-desc', label: 'Newest First' },
  { value: 'year-asc', label: 'Oldest First' },
];

const selectCls =
  'w-full appearance-none rounded-lg border border-white/10 bg-ink-800 px-3 py-2.5 text-sm text-silver-100 outline-none transition-colors focus:border-gold-400/50 focus:ring-1 focus:ring-gold-400/30';

export function FilterBar({ filters, onChange, onClear, brands, isDirty }: FilterBarProps) {
  const set = <K extends keyof FilterState>(key: K, value: FilterState[K]) =>
    onChange({ ...filters, [key]: value });

  return (
    <div className="card-surface p-5 sm:p-6">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-gold-300">
          <SlidersHorizontal className="h-4 w-4" />
          <span className="text-sm font-semibold uppercase tracking-wider">Filter &amp; Search</span>
        </div>
        {isDirty && (
          <button
            onClick={onClear}
            className="inline-flex items-center gap-1.5 rounded-full border border-silver-500/40 px-3 py-1.5 text-xs font-medium text-silver-200 transition-colors hover:border-gold-400 hover:text-gold-300"
          >
            <X className="h-3.5 w-3.5" />
            Clear Filters
          </button>
        )}
      </div>

      {/* Search */}
      <div className="relative mt-4">
        <Search className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-silver-400" />
        <input
          type="text"
          value={filters.query}
          onChange={(e) => set('query', e.target.value)}
          placeholder="Search by car name or model (e.g. Hilux, Aqua, 2022)…"
          className="w-full rounded-lg border border-white/10 bg-ink-800 py-3 pl-11 pr-4 text-sm text-white placeholder:text-silver-500 outline-none transition-colors focus:border-gold-400/50 focus:ring-1 focus:ring-gold-400/30"
        />
      </div>

      {/* Dropdowns */}
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6">
        <Select label="Brand" value={filters.brand} onChange={(v) => set('brand', v)}>
          <option value="">All Brands</option>
          {brands.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </Select>
        <Select label="Body Type" value={filters.bodyType} onChange={(v) => set('bodyType', v as BodyType | '')}>
          <option value="">All Types</option>
          {BODY_TYPES.map((b) => (
            <option key={b} value={b}>
              {b}
            </option>
          ))}
        </Select>
        <Select label="Fuel" value={filters.fuelType} onChange={(v) => set('fuelType', v as FuelType | '')}>
          <option value="">All Fuels</option>
          {FUELS.map((f) => (
            <option key={f} value={f}>
              {f}
            </option>
          ))}
        </Select>
        <Select
          label="Transmission"
          value={filters.transmission}
          onChange={(v) => set('transmission', v as Transmission | '')}
        >
          <option value="">All Transmissions</option>
          {TRANS.map((t) => (
            <option key={t} value={t}>
              {t}
            </option>
          ))}
        </Select>
        <Select label="Origin" value={filters.origin} onChange={(v) => set('origin', v as FilterState['origin'])}>
          <option value="">All Origins</option>
          <option value="Pakistani">Pakistani</option>
          <option value="Japanese">Japanese</option>
        </Select>
        <Select label="Sort" value={filters.sort} onChange={(v) => set('sort', v as FilterState['sort'])}>
          {SORTS.map((s) => (
            <option key={s.value} value={s.value}>
              {s.label}
            </option>
          ))}
        </Select>
      </div>

      {/* Price range */}
      <div className="mt-5">
        <div className="flex items-center justify-between text-xs text-silver-300">
          <span className="flex items-center gap-1.5">
            <ArrowUpDown className="h-3.5 w-3.5 text-gold-400" />
            Max Price
          </span>
          <span className="font-semibold text-gold-300">
            {filters.maxPrice >= MAX_PRICE_BOUND ? 'Any Price' : `Up to ${formatPKR(filters.maxPrice)}`}
          </span>
        </div>
        <input
          type="range"
          min={1000000}
          max={MAX_PRICE_BOUND}
          step={500000}
          value={filters.maxPrice}
          onChange={(e) => set('maxPrice', Number(e.target.value))}
          className="mt-2 w-full accent-gold-400"
        />
      </div>
    </div>
  );
}

function Select({
  label,
  value,
  onChange,
  children,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  children: React.ReactNode;
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[11px] font-medium uppercase tracking-wider text-silver-400">{label}</span>
      <select value={value} onChange={(e) => onChange(e.target.value)} className={selectCls}>
        {children}
      </select>
    </label>
  );
}
