import { Gauge, Fuel, Cog, Calendar, ArrowRight } from 'lucide-react';
import type { Car } from '@/types';
import { SmartImage } from './SmartImage';
import { formatPKR, formatMileage } from '@/lib/format';

interface CarCardProps {
  car: Car;
  onView: (car: Car) => void;
}

export function CarCard({ car, onView }: CarCardProps) {
  return (
    <article className="reveal card-surface group flex flex-col overflow-hidden transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-400/30 hover:shadow-[0_24px_60px_-24px_rgba(195,146,42,0.45)]">
      {/* Image */}
      <div className="relative aspect-[16/10] overflow-hidden">
        <SmartImage
          src={car.image}
          alt={car.name}
          className="h-full w-full"
          imgClassName="object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-900/80 via-transparent to-transparent" />
        <span className="absolute left-3 top-3 rounded-full border border-white/10 bg-ink-950/70 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-gold-300 backdrop-blur-sm">
          {car.origin}
        </span>
        <span className="absolute right-3 top-3 rounded-full bg-gold-400/90 px-3 py-1 text-xs font-bold text-ink-950">
          {formatPKR(car.pricePKR)}
        </span>
        <div className="absolute bottom-3 left-4 right-4 flex items-end justify-between">
          <div>
            <h3 className="font-display text-lg font-bold leading-tight text-white">{car.name}</h3>
            <p className="text-xs text-silver-300">
              {car.brand} · {car.bodyType}
            </p>
          </div>
        </div>
      </div>

      {/* Specs */}
      <div className="grid grid-cols-2 gap-px bg-white/5 text-silver-200">
        <Spec icon={Calendar} label={`${car.modelYear}`} />
        <Spec icon={Gauge} label={formatMileage(car.mileage)} />
        <Spec icon={Cog} label={car.transmission} />
        <Spec icon={Fuel} label={car.fuelType} />
      </div>

      {/* Footer */}
      <div className="mt-auto flex items-center justify-between p-5">
        <span className="text-sm font-semibold text-silver-100">{formatPKR(car.pricePKR)}</span>
        <button
          onClick={() => onView(car)}
          className="inline-flex items-center gap-1.5 rounded-full border border-gold-400/40 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-gold-300 transition-all duration-300 hover:bg-gold-400 hover:text-ink-950"
        >
          View Details
          <ArrowRight className="h-3.5 w-3.5" />
        </button>
      </div>
    </article>
  );
}

function Spec({ icon: Icon, label }: { icon: typeof Gauge; label: string }) {
  return (
    <div className="flex items-center gap-2 bg-ink-800 px-4 py-3">
      <Icon className="h-4 w-4 shrink-0 text-gold-400" />
      <span className="truncate text-xs font-medium">{label}</span>
    </div>
  );
}
