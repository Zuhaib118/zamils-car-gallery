import { ArrowRight } from 'lucide-react';
import { COLLECTIONS } from '@/data/cars';
import { SmartImage } from './SmartImage';
import { useReveal } from '@/hooks/useReveal';

interface CollectionsProps {
  onExplore: (collectionId: string) => void;
}

export function Collections({ onExplore }: CollectionsProps) {
  useReveal();
  return (
    <section id="collections" className="section-pad bg-ink-900 scroll-mt-20">
      <div className="max-w-site container-px">
        <div className="reveal mb-12 text-center">
          <p className="eyebrow">Collections</p>
          <h2 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
            Curated by Category
          </h2>
          <div className="mx-auto mt-5 gold-line" />
          <p className="mx-auto mt-6 max-w-2xl text-sm text-silver-300 sm:text-base">
            Six thoughtfully organised collections — explore the group that matches your style, and
            we&apos;ll filter the showroom instantly.
          </p>
        </div>

        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {COLLECTIONS.map((c, i) => (
            <article
              key={c.id}
              className="reveal group relative overflow-hidden rounded-2xl border border-white/5"
              style={{ transitionDelay: `${i * 70}ms` }}
            >
              <div className="relative aspect-[4/3] w-full overflow-hidden">
                <SmartImage
                  src={c.cover}
                  alt={c.title}
                  className="h-full w-full"
                  imgClassName="object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/50 to-transparent" />
              </div>

              <div className="absolute inset-0 flex flex-col justify-end p-6">
                <span className="mb-2 w-fit rounded-full border border-gold-400/40 bg-ink-950/60 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-gold-300 backdrop-blur-sm">
                  {c.tag}
                </span>
                <h3 className="font-display text-2xl font-bold text-white">{c.title}</h3>
                <p className="mt-2 line-clamp-2 text-sm text-silver-200">{c.description}</p>
                <button
                  onClick={() => onExplore(c.id)}
                  className="mt-4 inline-flex w-fit items-center gap-2 rounded-full bg-white/10 px-5 py-2.5 text-xs font-semibold uppercase tracking-wider text-white backdrop-blur-sm transition-all duration-300 group-hover:bg-gold-400 group-hover:text-ink-950"
                >
                  Explore Collection
                  <ArrowRight className="h-3.5 w-3.5" />
                </button>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
