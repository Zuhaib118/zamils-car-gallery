import { ShieldCheck, Layers, Headphones, HeartHandshake } from 'lucide-react';

const FEATURES = [
  {
    icon: ShieldCheck,
    title: 'Carefully Selected Vehicles',
    desc: 'Every car in our gallery is hand-picked and inspected for quality, condition and reliability before it reaches you.',
  },
  {
    icon: Layers,
    title: 'Diverse Car Collections',
    desc: 'From rugged pickups and 4x4 SUVs to efficient Japanese hybrids — find the category that fits your journey.',
  },
  {
    icon: Headphones,
    title: 'Personalized Assistance',
    desc: 'Our team guides you through every option, helping you compare and choose the vehicle that suits you best.',
  },
  {
    icon: HeartHandshake,
    title: 'A Smooth Buying Experience',
    desc: 'Transparent information, honest advice and a hassle-free process from enquiry to the keys in your hand.',
  },
];

export function WhyChooseUs() {
  return (
    <section className="section-pad bg-ink-900">
      <div className="max-w-site container-px">
        <div className="reveal mx-auto mb-14 max-w-2xl text-center">
          <p className="eyebrow">Why Choose Us</p>
          <h2 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
            A Standard Above the Ordinary
          </h2>
          <div className="mx-auto mt-5 gold-line" />
        </div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {FEATURES.map((f, i) => (
            <article
              key={f.title}
              className="reveal card-surface group p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-400/30 hover:shadow-[0_20px_50px_-20px_rgba(195,146,42,0.4)]"
              style={{ transitionDelay: `${i * 60}ms` }}
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-xl border border-gold-400/30 bg-gold-400/10 text-gold-300 transition-colors duration-500 group-hover:bg-gold-400 group-hover:text-ink-950">
                <f.icon className="h-6 w-6" />
              </span>
              <h3 className="mt-5 font-display text-xl font-semibold text-white">{f.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-silver-300">{f.desc}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
