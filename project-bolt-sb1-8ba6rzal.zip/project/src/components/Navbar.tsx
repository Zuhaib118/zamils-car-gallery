import { useEffect, useState } from 'react';
import { Menu, X, Car } from 'lucide-react';

interface NavbarProps {
  onNavigate: (section: string) => void;
  onExploreCars: () => void;
}

const LINKS: { label: string; id: string }[] = [
  { label: 'Home', id: 'home' },
  { label: 'All Cars', id: 'inventory' },
  { label: 'Collections', id: 'collections' },
  { label: 'Japanese Cars', id: 'japanese' },
  { label: 'Pakistani Cars', id: 'pakistani' },
  { label: 'About Us', id: 'about' },
  { label: 'Contact', id: 'contact' },
];

export function Navbar({ onNavigate, onExploreCars }: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const go = (id: string) => {
    setOpen(false);
    onNavigate(id);
  };

  return (
    <header
      className={`fixed inset-x-0 top-0 z-40 transition-all duration-500 ${
        scrolled
          ? 'bg-ink-950/90 backdrop-blur-xl border-b border-white/5 shadow-[0_8px_30px_-12px_rgba(0,0,0,0.8)]'
          : 'bg-gradient-to-b from-ink-950/70 to-transparent'
      }`}
    >
      <nav className="max-w-site container-px flex h-20 items-center justify-between gap-4">
        {/* Logo */}
        <button
          onClick={() => go('home')}
          className="flex items-center gap-3 text-left"
          aria-label="Zamil's Car Gallery home"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/40 bg-ink-900">
            <Car className="h-5 w-5 text-gold-400" />
          </span>
          <span className="leading-tight">
            <span className="block font-display text-lg font-bold tracking-wide text-white">
              ZAMIL&apos;S
            </span>
            <span className="block text-[10px] font-semibold uppercase tracking-[0.3em] text-gold-400">
              Car Gallery
            </span>
          </span>
        </button>

        {/* Desktop links */}
        <ul className="hidden items-center gap-1 lg:flex">
          {LINKS.map((l) => (
            <li key={l.id}>
              <button
                onClick={() => go(l.id)}
                className="rounded-full px-4 py-2 text-sm font-medium text-silver-200 transition-colors duration-300 hover:bg-white/5 hover:text-gold-300"
              >
                {l.label}
              </button>
            </li>
          ))}
        </ul>

        {/* CTA */}
        <div className="hidden lg:block">
          <button onClick={onExploreCars} className="btn-gold">
            Explore Cars
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-white lg:hidden"
          aria-label="Toggle menu"
          aria-expanded={open}
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      {/* Mobile menu */}
      <div
        className={`overflow-hidden border-t border-white/5 bg-ink-950/95 backdrop-blur-xl transition-[max-height,opacity] duration-300 lg:hidden ${
          open ? 'max-h-[640px] opacity-100' : 'max-h-0 opacity-0'
        }`}
      >
        <ul className="container-px flex flex-col gap-1 py-4">
          {LINKS.map((l) => (
            <li key={l.id}>
              <button
                onClick={() => go(l.id)}
                className="w-full rounded-lg px-4 py-3 text-left text-sm font-medium text-silver-200 transition-colors hover:bg-white/5 hover:text-gold-300"
              >
                {l.label}
              </button>
            </li>
          ))}
          <li className="pt-2">
            <button
              onClick={() => {
                setOpen(false);
                onExploreCars();
              }}
              className="btn-gold w-full"
            >
              Explore Cars
            </button>
          </li>
        </ul>
      </div>
    </header>
  );
}
