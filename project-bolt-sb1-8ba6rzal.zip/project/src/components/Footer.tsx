import { Car, Facebook, Instagram, Youtube, MessageCircle } from 'lucide-react';
import { SITE, whatsappLink } from '@/data/site';
import { COLLECTIONS } from '@/data/cars';

interface FooterProps {
  onNavigate: (id: string) => void;
}

const NAV = [
  { label: 'Home', id: 'home' },
  { label: 'All Cars', id: 'inventory' },
  { label: 'Collections', id: 'collections' },
  { label: 'Japanese Cars', id: 'japanese' },
  { label: 'Pakistani Cars', id: 'pakistani' },
  { label: 'About Us', id: 'about' },
  { label: 'Contact', id: 'contact' },
];

export function Footer({ onNavigate }: FooterProps) {
  return (
    <footer className="border-t border-white/5 bg-ink-950">
      <div className="max-w-site container-px py-14">
        <div className="grid gap-10 lg:grid-cols-4">
          {/* Brand */}
          <div className="lg:col-span-1">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-400/40 bg-ink-900">
                <Car className="h-5 w-5 text-gold-400" />
              </span>
              <span className="leading-tight">
                <span className="block font-display text-lg font-bold tracking-wide text-white">
                  ZAMIL&apos;S
                </span>
                <span className="block text-[10px] font-semibold uppercase tracking-[0.3em] text-gold-400">
                  Car Gallery
                </span>
              </span>
            </div>
            <p className="mt-4 text-sm leading-relaxed text-silver-400">{SITE.tagline}</p>
            <div className="mt-5 flex gap-3">
              <Social href={SITE.social.facebook} label="Facebook">
                <Facebook className="h-4 w-4" />
              </Social>
              <Social href={SITE.social.instagram} label="Instagram">
                <Instagram className="h-4 w-4" />
              </Social>
              <Social href={SITE.social.youtube} label="YouTube">
                <Youtube className="h-4 w-4" />
              </Social>
              <Social href={whatsappLink(`Hello ${SITE.brand}`)} label="WhatsApp">
                <MessageCircle className="h-4 w-4" />
              </Social>
            </div>
          </div>

          {/* Navigation */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gold-400">Navigation</h4>
            <ul className="mt-4 space-y-2.5">
              {NAV.map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() => onNavigate(l.id)}
                    className="text-sm text-silver-400 transition-colors hover:text-gold-300"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Collections */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gold-400">Collections</h4>
            <ul className="mt-4 space-y-2.5">
              {COLLECTIONS.map((c) => (
                <li key={c.id}>
                  <button
                    onClick={() => onNavigate('collections')}
                    className="text-left text-sm text-silver-400 transition-colors hover:text-gold-300"
                  >
                    {c.title.replace(' Collection', '')}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h4 className="text-xs font-semibold uppercase tracking-wider text-gold-400">Contact</h4>
            <ul className="mt-4 space-y-2.5 text-sm text-silver-400">
              <li>{SITE.phoneDisplay}</li>
              <li>{SITE.email}</li>
              <li>{SITE.address}</li>
            </ul>
            <button
              onClick={() => onNavigate('contact')}
              className="btn-ghost mt-5 px-5 py-2.5 text-xs"
            >
              Send Enquiry
            </button>
          </div>
        </div>
      </div>

      <div className="border-t border-white/5">
        <div className="max-w-site container-px flex flex-col items-center justify-between gap-2 py-6 text-xs text-silver-500 sm:flex-row">
          <p>© {new Date().getFullYear()} {SITE.brand}. All rights reserved.</p>
          <p>Illustrative sample inventory — prices and specs are for demonstration.</p>
        </div>
      </div>
    </footer>
  );
}

function Social({
  href,
  label,
  children,
}: {
  href: string;
  label: string;
  children: React.ReactNode;
}) {
  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={label}
      className="flex h-9 w-9 items-center justify-center rounded-full border border-white/10 text-silver-300 transition-all duration-300 hover:border-gold-400 hover:bg-gold-400 hover:text-ink-950"
    >
      {children}
    </a>
  );
}
