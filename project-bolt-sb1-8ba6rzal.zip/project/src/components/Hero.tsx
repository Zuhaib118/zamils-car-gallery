import { ChevronRight, Search, Sparkles } from 'lucide-react';
import { SmartImage } from './SmartImage';
import { HERO_IMAGE } from '@/data/cars';

interface HeroProps {
  onExplore: () => void;
  onFind: () => void;
}

export function Hero({ onExplore, onFind }: HeroProps) {
  return (
    <section id="home" className="relative min-h-[100svh] w-full overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <SmartImage
          src={HERO_IMAGE}
          alt="Luxury car at night with illuminated headlights"
          loading="eager"
          className="h-full w-full"
          imgClassName="object-cover animate-slow-zoom"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-ink-950 via-ink-950/55 to-ink-950/70" />
        <div className="absolute inset-0 bg-gradient-to-r from-ink-950/80 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative z-10 mx-auto flex min-h-[100svh] max-w-site flex-col justify-center container-px pt-28 pb-20">
        <div className="max-w-3xl animate-fade-up">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-ink-900/60 px-4 py-1.5 backdrop-blur-sm">
            <Sparkles className="h-4 w-4 text-gold-400" />
            <span className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-300">
              Premium Pakistani &amp; Japanese Cars
            </span>
          </div>

          <h1 className="font-display text-5xl font-bold leading-[1.05] text-white sm:text-6xl lg:text-7xl">
            Your Dream Car
            <span className="block gold-text">Awaits.</span>
          </h1>

          <p className="mt-6 max-w-2xl text-base leading-relaxed text-silver-200 sm:text-lg">
            Explore an exceptional collection of premium, reliable, and stylish vehicles. From
            powerful pickups to elegant sedans and fuel-efficient Japanese imports, discover the car
            that matches your lifestyle.
          </p>

          <div className="mt-9 flex flex-col gap-3 sm:flex-row sm:items-center">
            <button onClick={onExplore} className="btn-gold">
              Explore Our Collection
              <ChevronRight className="h-4 w-4" />
            </button>
            <button onClick={onFind} className="btn-ghost">
              <Search className="h-4 w-4" />
              Find Your Dream Car
            </button>
          </div>

          <div className="mt-10 flex flex-wrap items-center gap-x-3 gap-y-2 text-xs font-medium uppercase tracking-[0.18em] text-silver-300">
            <span className="text-gold-300">Quality Cars</span>
            <span className="text-silver-500">|</span>
            <span className="text-gold-300">Trusted Service</span>
            <span className="text-silver-500">|</span>
            <span className="text-gold-300">Your Next Journey</span>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <div className="absolute bottom-6 left-1/2 z-10 -translate-x-1/2">
        <div className="flex h-10 w-6 items-start justify-center rounded-full border border-white/20 p-1.5">
          <span className="h-2 w-1 animate-bounce rounded-full bg-gold-400" />
        </div>
      </div>
    </section>
  );
}
