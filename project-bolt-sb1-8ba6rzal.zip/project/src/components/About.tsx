import { useReveal } from '@/hooks/useReveal';

export function About() {
  useReveal();
  return (
    <section id="about" className="section-pad bg-ink-950">
      <div className="max-w-site container-px grid items-center gap-12 lg:grid-cols-2">
        <div className="reveal">
          <p className="eyebrow">About Us</p>
          <h2 className="mt-3 font-display text-4xl font-bold leading-tight text-white sm:text-5xl">
            More Than Cars.
            <span className="block gold-text">A Passion for Every Journey.</span>
          </h2>
          <div className="mt-5 gold-line" />
          <p className="mt-7 text-base leading-relaxed text-silver-200 sm:text-lg">
            At Zamil&apos;s Car Gallery, we bring together style, performance, comfort, and
            reliability. Our collection is designed for drivers who appreciate quality and want to
            find a vehicle that feels right for their next journey.
          </p>
          <p className="mt-5 text-sm leading-relaxed text-silver-400">
            Every vehicle listed here is shown with illustrative sample details to demonstrate the
            browsing experience. Prices, mileage and specifications can be updated at any time, and
            each car can be connected to a live database when you are ready.
          </p>
        </div>

        <div className="reveal grid grid-cols-2 gap-4">
          {[
            { k: '34', l: 'Curated Vehicles' },
            { k: '6', l: 'Collections' },
            { k: '11', l: 'Brands' },
            { k: '2', l: 'Origins — Japan & Pakistan' },
          ].map((s) => (
            <div
              key={s.l}
              className="card-surface flex flex-col items-start gap-1 p-7 transition-colors duration-500 hover:border-gold-400/30"
            >
              <span className="font-display text-4xl font-bold gold-text">{s.k}</span>
              <span className="text-sm font-medium text-silver-300">{s.l}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
