import { useMemo } from 'react';
import { CARS, COLLECTIONS } from '@/data/cars';
import type { Car } from '@/types';
import { CarCard } from './CarCard';
import { FilterBar } from './FilterBar';
import {
  defaultFilters,
  applyFilters,
  isDefaultFilters,
  type FilterState,
} from '@/lib/filters';
import { useReveal } from '@/hooks/useReveal';
import { CarFront } from 'lucide-react';

interface InventoryProps {
  filters: FilterState;
  onFiltersChange: (f: FilterState) => void;
  onView: (car: Car) => void;
}

export function Inventory({ filters, onFiltersChange, onView }: InventoryProps) {
  const brands = useMemo(() => Array.from(new Set(CARS.map((c) => c.brand))).sort(), []);

  const results = useMemo(() => applyFilters(CARS, filters), [filters]);
  useReveal([filters]);

  const clear = () => onFiltersChange({ ...defaultFilters });

  return (
    <section id="inventory" className="section-pad bg-ink-950 scroll-mt-20">
      <div className="max-w-site container-px">
        <div className="reveal mb-10 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <div>
            <p className="eyebrow">All Cars</p>
            <h2 className="mt-2 font-display text-4xl font-bold text-white sm:text-5xl">
              The Full Collection
            </h2>
            <div className="mt-4 gold-line" />
            {filters.collection && (
              <div className="mt-4 inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-400/10 px-4 py-1.5 text-xs font-semibold uppercase tracking-wider text-gold-300">
                {COLLECTIONS.find((c) => c.id === filters.collection)?.title ?? 'Collection'}
                <button
                  onClick={() => onFiltersChange({ ...filters, collection: '' })}
                  className="ml-1 text-gold-300 hover:text-white"
                  aria-label="Clear collection filter"
                >
                  ×
                </button>
              </div>
            )}
          </div>
          <p className="text-sm text-silver-300">
            Showing{' '}
            <span className="font-semibold text-gold-300">{results.length}</span> of {CARS.length}{' '}
            vehicles
          </p>
        </div>

        <FilterBar
          filters={filters}
          onChange={onFiltersChange}
          onClear={clear}
          brands={brands}
          isDirty={!isDefaultFilters(filters)}
        />

        {results.length > 0 ? (
          <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {results.map((car) => (
              <CarCard key={car.id} car={car} onView={onView} />
            ))}
          </div>
        ) : (
          <div className="mt-12 flex flex-col items-center justify-center rounded-2xl border border-white/5 bg-ink-900/60 py-20 text-center">
            <CarFront className="h-12 w-12 text-silver-500" />
            <p className="mt-4 font-display text-xl text-white">No cars match your filters</p>
            <p className="mt-2 text-sm text-silver-400">
              Try adjusting the search or clearing filters to see all vehicles.
            </p>
            <button onClick={clear} className="btn-ghost mt-6">
              Clear Filters
            </button>
          </div>
        )}
      </div>
    </section>
  );
}
