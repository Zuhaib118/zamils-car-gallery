import { useState, type FormEvent } from 'react';
import { Phone, Mail, MapPin, Send, MessageCircle, Check } from 'lucide-react';
import { SITE, whatsappLink } from '@/data/site';
import { useReveal } from '@/hooks/useReveal';
import { CARS } from '@/data/cars';

export function Contact() {
  useReveal();
  const [sent, setSent] = useState(false);
  const [form, setForm] = useState({
    name: '',
    phone: '',
    email: '',
    car: '',
    message: '',
  });

  const update = (k: keyof typeof form, v: string) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
    // In a real deployment this would POST to a Supabase table or edge function.
    setTimeout(() => setSent(false), 6000);
    setForm({ name: '', phone: '', email: '', car: '', message: '' });
  };

  const waMsg = `Hello ${SITE.brand}, I have an enquiry.%0A%0AName: ${form.name || '-'}%0APhone: ${
    form.phone || '-'
  }%0ACar of interest: ${form.car || '-'}%0AMessage: ${form.message || '-'}`;

  const inputCls =
    'w-full rounded-lg border border-white/10 bg-ink-800 px-4 py-3 text-sm text-white placeholder:text-silver-500 outline-none transition-colors focus:border-gold-400/50 focus:ring-1 focus:ring-gold-400/30';

  return (
    <section id="contact" className="section-pad bg-ink-950 scroll-mt-20">
      <div className="max-w-site container-px grid gap-12 lg:grid-cols-2">
        {/* Info */}
        <div className="reveal">
          <p className="eyebrow">Contact</p>
          <h2 className="mt-3 font-display text-4xl font-bold text-white sm:text-5xl">
            Let&apos;s Find Your Next Car
          </h2>
          <div className="mt-5 gold-line" />
          <p className="mt-6 text-sm leading-relaxed text-silver-300 sm:text-base">
            Have a question about any vehicle, or want to arrange a visit? Send us an enquiry and
            we&apos;ll get back to you, or reach us instantly on WhatsApp.
          </p>

          <div className="mt-8 space-y-4">
            <ContactRow icon={Phone} label="Phone" value={SITE.phoneDisplay} note="Replace in site settings" />
            <ContactRow icon={Mail} label="Email" value={SITE.email} note="Replace in site settings" />
            <ContactRow icon={MapPin} label="Showroom" value={SITE.address} note="Replace in site settings" />
          </div>

          <a
            href={whatsappLink(`Hello ${SITE.brand}, I'd like to enquire about a vehicle.`)}
            target="_blank"
            rel="noopener noreferrer"
            className="mt-8 inline-flex items-center justify-center gap-2 rounded-full bg-[#25D366] px-7 py-3.5 text-sm font-semibold uppercase tracking-wider text-white transition-all duration-300 hover:brightness-110"
          >
            <MessageCircle className="h-4 w-4" />
            Chat on WhatsApp
          </a>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="reveal card-surface p-6 sm:p-8">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Name">
              <input
                required
                value={form.name}
                onChange={(e) => update('name', e.target.value)}
                placeholder="Your full name"
                className={inputCls}
              />
            </Field>
            <Field label="Phone Number">
              <input
                required
                type="tel"
                value={form.phone}
                onChange={(e) => update('phone', e.target.value)}
                placeholder="03XX XXXXXXX"
                className={inputCls}
              />
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Email">
              <input
                type="email"
                value={form.email}
                onChange={(e) => update('email', e.target.value)}
                placeholder="you@example.com"
                className={inputCls}
              />
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Car of Interest">
              <select
                value={form.car}
                onChange={(e) => update('car', e.target.value)}
                className={inputCls}
              >
                <option value="">Select a vehicle (optional)</option>
                {CARS.map((c) => (
                  <option key={c.id} value={c.name}>
                    {c.name} — {c.modelYear}
                  </option>
                ))}
              </select>
            </Field>
          </div>

          <div className="mt-4">
            <Field label="Message">
              <textarea
                value={form.message}
                onChange={(e) => update('message', e.target.value)}
                rows={4}
                placeholder="Tell us what you're looking for…"
                className={`${inputCls} resize-none`}
              />
            </Field>
          </div>

          <div className="mt-6 flex flex-col gap-3 sm:flex-row">
            <button type="submit" className="btn-gold flex-1">
              <Send className="h-4 w-4" />
              Submit Enquiry
            </button>
            <a
              href={`https://wa.me/${SITE.whatsappNumber}?text=${waMsg}`}
              target="_blank"
              rel="noopener noreferrer"
              className="btn-ghost flex-1"
            >
              <MessageCircle className="h-4 w-4" />
              Send via WhatsApp
            </a>
          </div>

          {sent && (
            <p className="mt-4 flex items-center gap-2 rounded-lg border border-green-500/30 bg-green-500/10 px-4 py-3 text-sm text-green-300">
              <Check className="h-4 w-4" />
              Thank you — your enquiry has been noted. We&apos;ll be in touch soon.
            </p>
          )}
        </form>
      </div>
    </section>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[11px] font-medium uppercase tracking-wider text-silver-400">{label}</span>
      {children}
    </label>
  );
}

function ContactRow({
  icon: Icon,
  label,
  value,
  note,
}: {
  icon: typeof Phone;
  label: string;
  value: string;
  note: string;
}) {
  return (
    <div className="flex items-start gap-4 rounded-xl border border-white/5 bg-ink-800/60 p-4">
      <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border border-gold-400/30 bg-gold-400/10 text-gold-300">
        <Icon className="h-5 w-5" />
      </span>
      <div>
        <p className="text-[11px] uppercase tracking-wider text-silver-400">{label}</p>
        <p className="text-sm font-semibold text-white">{value}</p>
        <p className="text-[11px] text-silver-500">{note}</p>
      </div>
    </div>
  );
}
