import { MessageCircle } from 'lucide-react';
import { whatsappLink } from '@/data/site';

interface WhatsAppFloatProps {
  message?: string;
}

/** Floating WhatsApp action button, always visible. */
export function WhatsAppFloat({
  message = "Hello Zamil's Car Gallery, I'd like to enquire about a vehicle.",
}: WhatsAppFloatProps) {
  return (
    <a
      href={whatsappLink(message)}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Chat on WhatsApp"
      className="fixed bottom-5 right-5 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-[#25D366] text-white shadow-[0_8px_30px_-6px_rgba(37,211,102,0.6)] transition-all duration-300 hover:scale-110 hover:shadow-[0_10px_36px_-6px_rgba(37,211,102,0.8)]"
    >
      <MessageCircle className="h-6 w-6" />
      <span className="absolute inset-0 -z-10 animate-ping rounded-full bg-[#25D366] opacity-30" />
    </a>
  );
}
