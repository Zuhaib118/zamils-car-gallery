import { useEffect, useState } from 'react';
import {
  X,
  ChevronLeft,
  ChevronRight,
  Gauge,
  Fuel,
  Cog,
  Calendar,
  Car as CarIcon,
  MessageCircle,
  Phone,
  Check,
} from 'lucide-react';
import type { Car } from '@/types';
import { SmartImage } from './SmartImage';
import { formatPKRFull, formatMileage } from '@/lib/format';
import { whatsappLink, SITE } from '@/data/site';

interface CarDetailModalProps {
  car: Car | null;
  onClose: () => void;
}

export function CarDetailModal({ car, onClose }: CarDetailModalProps) {
  const [active, setActive] = useState(0);

  // Reset gallery + lock body scroll while open
  useEffect(() => {
    setActive(0);
    if (car) {
      document.body.style.overflow = 'hidden';
      const onKey = (e: KeyboardEvent) => {
        if (e.key === 'Escape') onClose();
      };
      window.addEventListener('keydown', onKey);
      return () => {
        document.body.style.overflow = '';
        window.removeEventListener('keydown', onKey);
      };
    }
  }, [car, onClose]);

  if (!car) return null;
  const gallery = car.gallery.length ? car.gallery : [car.image];

  const enquiryMsg = `Hello ${SITE.brand}, I'm interested in the ${car.name} (${car.modelYear}) listed at ${formatPKRFull(
    car.pricePKR
  )}. Could you share more details?`;

  const next = () => setActive((i) => (i + 1) % gallery.length);
  const prev = () => setActive((i) => (i - 1 + gallery.length) % gallery.length);

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-ink-950/80 p-3 backdrop-blur-md sm:p-6"
      onClick={onClose}
      role="dialog"
      aria-modal="true"
      aria-label={`${car.name} details`}
    >
      <div
        className="relative max-h-[92vh] w-full max-w-5xl overflow-y-auto rounded-2xl border border-white/10 bg-ink-900 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          aria-label="Close details"
          className="absolute right-3 top-3 z-20 flex h-10 w-10 items-center justify-center rounded-full bg-ink-950/70 text-white transition-colors hover:bg-gold-400 hover:text-ink-950"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="grid lg:grid-cols-2">
          {/* Gallery */}
          <div className="relative">
            <div className="relative aspect-[16/11] w-full overflow-hidden bg-ink-800 lg:aspect-auto lg:h-full">
              <SmartImage
                src={gallery[active]}
                alt={`${car.name} view ${active + 1}`}
                loading="eager"
                className="h-full w-full"
                imgClassName="object-cover"
              />
              {gallery.length > 1 && (
                <>
                  <button
                    onClick={prev}
                    aria-label="Previous image"
                    className="absolute left-3 top-1/2 -translate-y-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-ink-950/70 text-white transition-colors hover:bg-gold-400 hover:text-ink-950"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>
                  <button
                    onClick={next}
                    aria-label="Next image"
                    className="absolute right-3 top-1/2 -translate-y-1/2 flex h-10 w-10 items-center justify-center rounded-full bg-ink-950/70 text-white transition-colors hover:bg-gold-400 hover:text-ink-950"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>
                  <div className="absolute bottom-3 left-1/2 -translate-x-1/2 rounded-full bg-ink-950/70 px-3 py-1 text-xs text-white">
                    {active + 1} / {gallery.length}
                  </div>
                </>
              )}
            </div>
            {gallery.length > 1 && (
              <div className="flex gap-2 overflow-x-auto p-3 lg:absolute lg:bottom-0 lg:left-0 lg:right-0">
                {gallery.map((g, i) => (
                  <button
                    key={g}
                    onClick={() => setActive(i)}
                    className={`relative h-16 w-24 shrink-0 overflow-hidden rounded-lg border-2 transition-all ${
                      i === active ? 'border-gold-400' : 'border-transparent opacity-60'
                    }`}
                  >
                    <SmartImage src={g} alt="" className="h-full w-full" imgClassName="object-cover" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Info */}
          <div className="flex flex-col p-6 sm:p-8">
            <span className="eyebrow">{car.origin} · {car.bodyType}</span>
            <h2 className="mt-2 font-display text-3xl font-bold text-white">{car.name}</h2>
            <p className="mt-1 text-sm text-silver-300">
              {car.brand} · {car.modelYear} · {car.condition}
            </p>

            <div className="mt-5 rounded-xl border border-gold-400/20 bg-gold-400/5 p-4">
              <p className="text-xs uppercase tracking-wider text-silver-400">Price</p>
              <p className="font-display text-3xl font-bold gold-text">{formatPKRFull(car.pricePKR)}</p>
              <p className="mt-1 text-xs text-silver-400">
                Illustrative sample price — confirm final pricing on enquiry.
              </p>
            </div>

            {/* Specs grid */}
            <div className="mt-6 grid grid-cols-2 gap-3">
              <SpecRow icon={Calendar} label="Model Year" value={`${car.modelYear}`} />
              <SpecRow icon={Gauge} label="Mileage" value={formatMileage(car.mileage)} />
              <SpecRow icon={Cog} label="Transmission" value={car.transmission} />
              <SpecRow icon={Fuel} label="Fuel Type" value={car.fuelType} />
              <SpecRow icon={CarIcon} label="Engine" value={car.engine} />
              <SpecRow icon={Check} label="Condition" value={car.condition} />
            </div>

            {/* Key specs list */}
            <dl className="mt-6 grid grid-cols-2 gap-x-6 gap-y-3 border-t border-white/5 pt-6">
              {car.specs.map((s) => (
                <div key={s.label} className="flex flex-col">
                  <dt className="text-xs uppercase tracking-wider text-silver-400">{s.label}</dt>
                  <dd className="text-sm font-semibold text-white">{s.value}</dd>
                </div>
              ))}
            </dl>

            <p className="mt-6 text-sm leading-relaxed text-silver-200">{car.description}</p>

            {/* Actions */}
            <div className="mt-8 flex flex-col gap-3 sm:flex-row">
              <a
                href={whatsappLink(enquiryMsg)}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-full bg-[#25D366] px-6 py-3.5 text-sm font-semibold uppercase tracking-wider text-white transition-all duration-300 hover:brightness-110 active:scale-[0.98]"
              >
                <MessageCircle className="h-4 w-4" />
                WhatsApp Enquiry
              </a>
              <a
                href={whatsappLink(enquiryMsg)}
                target="_blank"
                rel="noopener noreferrer"
                className="btn-gold flex-1"
              >
                <Phone className="h-4 w-4" />
                Enquire Now
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function SpecRow({
  icon: Icon,
  label,
  value,
}: {
  icon: typeof Gauge;
  label: string;
  value: string;
}) {
  return (
    <div className="flex items-center gap-3 rounded-lg border border-white/5 bg-ink-800/60 px-3 py-2.5">
      <Icon className="h-4 w-4 shrink-0 text-gold-400" />
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wider text-silver-400">{label}</p>
        <p className="truncate text-sm font-semibold text-white">{value}</p>
      </div>
    </div>
  );
}
