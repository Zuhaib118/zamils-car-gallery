import { useCallback, useState } from 'react';
import { Navbar } from '@/components/Navbar';
import { Hero } from '@/components/Hero';
import { Collections } from '@/components/Collections';
import { Inventory } from '@/components/Inventory';
import { About } from '@/components/About';
import { WhyChooseUs } from '@/components/WhyChooseUs';
import { Contact } from '@/components/Contact';
import { Footer } from '@/components/Footer';
import { CarDetailModal } from '@/components/CarDetailModal';
import { WhatsAppFloat } from '@/components/WhatsAppFloat';
import { defaultFilters, type FilterState } from '@/lib/filters';
import { useReveal } from '@/hooks/useReveal';
import type { Car } from '@/types';
import { ShieldCheck, Fuel, Cog, Car as CarIcon, Gauge } from 'lucide-react';

export default function App() {
  const [filters, setFilters] = useState<FilterState>(defaultFilters);
  const [selected, setSelected] = useState<Car | null>(null);
  useReveal([selected]);

  const scrollTo = useCallback((id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, []);

  const handleNavigate = useCallback(
    (id: string) => {
      if (id === 'japanese') {
        setFilters({ ...defaultFilters, origin: 'Japanese' });
        scrollTo('inventory');
        return;
      }
      if (id === 'pakistani') {
        setFilters({ ...defaultFilters, origin: 'Pakistani' });
        scrollTo('inventory');
        return;
      }
      if (id === 'home') {
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
      scrollTo(id);
    },
    [scrollTo]
  );

  const handleExploreCollection = useCallback(
    (collectionId: string) => {
      setFilters({ ...defaultFilters, collection: collectionId });
      scrollTo('inventory');
    },
    [scrollTo]
  );

  const exploreCars = useCallback(() => {
    setFilters({ ...defaultFilters });
    scrollTo('inventory');
  }, [scrollTo]);

  const findDreamCar = useCallback(() => {
    setFilters({ ...defaultFilters });
    scrollTo('inventory');
    // Focus the search input shortly after scroll
    setTimeout(() => {
      const input = document.querySelector<HTMLInputElement>(
        'input[placeholder^="Search by car name"]'
      );
      input?.focus();
    }, 600);
  }, [scrollTo]);

  return (
    <div className="min-h-screen bg-ink-950">
      <Navbar onNavigate={handleNavigate} onExploreCars={exploreCars} />

      <main>
        <Hero onExplore={exploreCars} onFind={findDreamCar} />

        <BrandStrip />

        <Collections onExplore={handleExploreCollection} />

        <Inventory filters={filters} onFiltersChange={setFilters} onView={setSelected} />

        <WhyChooseUs />

        <About />

        <Contact />
      </main>

      <Footer onNavigate={handleNavigate} />

      <CarDetailModal car={selected} onClose={() => setSelected(null)} />
      <WhatsAppFloat />
    </div>
  );
}

/** Slim premium band highlighting the showroom's scope. */
function BrandStrip() {
  const stats = [
    { icon: CarIcon, label: 'Vehicles', value: '34' },
    { icon: ShieldCheck, label: 'Collections', value: '6' },
    { icon: Fuel, label: 'Fuel Types', value: '3' },
    { icon: Cog, label: 'Transmissions', value: '3' },
    { icon: Gauge, label: 'Brands', value: '11' },
  ];
  return (
    <section className="border-y border-white/5 bg-ink-900/60">
      <div className="max-w-site container-px grid grid-cols-2 divide-x divide-white/5 py-6 sm:grid-cols-3 lg:grid-cols-5">
        {stats.map((s) => (
          <div key={s.label} className="flex items-center justify-center gap-3 px-4 py-3">
            <s.icon className="h-5 w-5 text-gold-400" />
            <div className="leading-tight">
              <p className="font-display text-xl font-bold text-white">{s.value}</p>
              <p className="text-[11px] uppercase tracking-wider text-silver-400">{s.label}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
