/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        ink: {
          950: '#0a0a0b',
          900: '#0e0e10',
          800: '#16161a',
          700: '#1f1f24',
          600: '#2a2a30',
        },
        gold: {
          50: '#fbf6e9',
          100: '#f6ebcc',
          200: '#ecd594',
          300: '#e0bd5e',
          400: '#d4a73c',
          500: '#c3922a',
          600: '#a6761f',
          700: '#84591b',
          800: '#5c3e15',
          900: '#3a2810',
        },
        silver: {
          50: '#f7f7f8',
          100: '#ededf0',
          200: '#dcdce1',
          300: '#c2c2ca',
          400: '#9a9aa6',
          500: '#777783',
          600: '#5a5a66',
          700: '#44444e',
        },
      },
      fontFamily: {
        display: ['"Playfair Display"', 'Georgia', 'serif'],
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
      keyframes: {
        'fade-up': {
          '0%': { opacity: '0', transform: 'translateY(24px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        'fade-in': {
          '0%': { opacity: '0' },
          '100%': { opacity: '1' },
        },
        'slow-zoom': {
          '0%': { transform: 'scale(1.08)' },
          '100%': { transform: 'scale(1)' },
        },
        shimmer: {
          '0%': { backgroundPosition: '-700px 0' },
          '100%': { backgroundPosition: '700px 0' },
        },
      },
      animation: {
        'fade-up': 'fade-up 0.7s ease-out both',
        'fade-in': 'fade-in 0.8s ease-out both',
        'slow-zoom': 'slow-zoom 8s ease-out both',
        shimmer: 'shimmer 2.2s linear infinite',
      },
    },
  },
  plugins: [],
};
